<template>
  <div class="modal-note-div">
    <q-card>
      <q-card-section>
        <q-item-label v-if="copyNote.title"><b>{{ copyNote.title }}</b></q-item-label>
        <q-popup-edit v-model="copyNote.title" content-class="bg-white text-black">
          <q-input white color="white" v-model="copyNote.title" dense autofocus counter clearable>
            <template v-slot:append>
              <q-icon name="edit"/>
            </template>
          </q-input>
        </q-popup-edit>
        <q-item-label caption v-if="copyNote.startDate || copyNote.endDate"><b v-if="copyNote.startDate">Start date:</b>
          {{ copyNote.startDate }} <b v-if="copyNote.endDate"> End date:</b>
          {{ copyNote.endDate }}
        </q-item-label>
        <q-item-label caption v-if="copyNote.startTime || copyNote.endTime"><b v-if="copyNote.startTime">Start time:</b>
          {{ copyNote.startTime }} <b v-if="copyNote.endTime"> End time:</b> {{ copyNote.endTime }}
        </q-item-label>
      </q-card-section>

      <q-separator inset/>

      <q-card-section>
        <q-item-label v-if="copyNote.description"><b>Description: </b>{{ copyNote.description }}</q-item-label>
        <q-popup-edit v-model="copyNote.description" content-class="bg-white text-black">
          <q-input white color="white" v-model="copyNote.description" dense autofocus counter clearable>
            <template v-slot:append>
              <q-icon name="edit"/>
            </template>
          </q-input>
        </q-popup-edit>
      </q-card-section>

      <q-separator inset/>

      <q-card-section>
        <q-item-label v-if="copyNote.location"><b>Location: </b>{{ copyNote.location }}</q-item-label>
        <q-item-label v-if="copyNote.url"><b>URL: </b>{{ copyNote.url }}</q-item-label>
      </q-card-section>

      <q-card-section>
        <q-btn class="q-ma-md" @click="deleteNote" label="Delete" type="submit" color="primary"/>
        <q-btn class="q-ma-md" @click="updateNote" label="Update" type="submit" color="primary"/>
      </q-card-section>


      <!--    </q-card-section>-->
    </q-card>
  </div>
</template>


<script>
window.console = console;

export default {
  name: "ModalNote",
  props: {
    note: Object
  },
  data() {
    return{
      copyNote: {}
    }
  },
  mounted() {
    this.copyNote = JSON.parse(JSON.stringify(this.note));
    console.log(this.copyNote);
  },
  methods: {
    updateNote() {
      console.log(JSON.stringify(this.copyNote));
      this.$emit('update', this.copyNote);
    },
    deleteNote() {
      let notes = JSON.parse(localStorage.getItem("notes") || "[]")
      let filteredNotes = notes.filter((n) => n.id !== this.note.id);
      localStorage.setItem("notes", JSON.stringify(filteredNotes));
      this.$emit('delete');
    }
  }
}
;
</script>

<style scoped>
.modal-note-div {
  cursor: pointer;
  margin: 10px;
  width: 500px;
}
</style>