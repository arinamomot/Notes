<template>
  <div></div>
</template>

<script>
export default {
  name: "HelloWorld"
}
</script>

<style scoped>

</style>